package com.example.user.fortointerface;

import android.app.Activity;
import android.os.Bundle;

public class LanguageSelection extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_language_selection);

    }
}
