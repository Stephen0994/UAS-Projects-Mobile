package com.example.user.fortointerface;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import com.google.api.translate.Language;
import com.google.api.translate.Translate;

public class Translator extends Activity {
    ImageButton btnPopup;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_translator);
        btnPopup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PopupMenu popUpMenu=new PopupMenu(Translator.this,view);
                popUpMenu.getMenuInflater().inflate(R.menu.popup_menu,popUpMenu.getMenu());
                popUpMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        switch (item.getItemId()){
                            case R.id.itemLanguage:
                                startActivity(new Intent(Translator.this,MainMenu.class));
                                Toast.makeText(getApplicationContext(),"Select Language",Toast.LENGTH_LONG).show();
                                return true;

                            case R.id.itemTranslator:
                                Toast.makeText(getApplicationContext(),"Translator",Toast.LENGTH_LONG).show();
                                return true;

                            case R.id.itemProfile:
                                Toast.makeText(getApplicationContext(),"Profile",Toast.LENGTH_LONG).show();
                                return true;
                        }

                        return true;
                    }
                });
                popUpMenu.show();
            }
        });
    }


}
