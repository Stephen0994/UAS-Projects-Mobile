package com.example.user.fortointerface;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.PopupMenu;
import android.widget.Toast;
import android.widget.Toolbar;

public class Questions extends Activity {
    ImageButton btnPopup2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questions);
        btnPopup2=(ImageButton)findViewById(R.id.btnPupop);
        btnPopup2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PopupMenu popUpMenu=new PopupMenu(Questions.this,view);
                popUpMenu.getMenuInflater().inflate(R.menu.popup_menu2,popUpMenu.getMenu());
                popUpMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        switch (item.getItemId()){
                            case R.id.itemBack:
                                startActivity(new Intent(Questions.this,MainMenu.class));
                                Toast.makeText(getApplicationContext(),"Back to Course",Toast.LENGTH_LONG).show();
                                return true;

                            case R.id.itemTranslator:
                                Toast.makeText(getApplicationContext(),"Signup",Toast.LENGTH_LONG).show();
                                return true;

                            case R.id.itemProfile:
                                Toast.makeText(getApplicationContext(),"Profile",Toast.LENGTH_LONG).show();
                                return true;
                        }

                        return true;
                    }
                });
                popUpMenu.show();
            }
        });
    }
}

